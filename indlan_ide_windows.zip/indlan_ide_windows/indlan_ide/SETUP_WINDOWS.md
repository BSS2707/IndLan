# IndLan IDE — Windows Setup Guide

This turns IndLan into a real desktop app on Windows:

- **`IndLanIDE.exe`** — a VS Code-style editor (tabs, syntax highlighting,
  line numbers, Run/Stop, output console with live `input()` support) for
  writing and running `.ind` files. No Python installation needed to *run*
  the exe once it's built.
- **`.ind` files get the IndLan icon** in File Explorer, and double-clicking
  one opens it directly in IndLanIDE.exe.

Everything here was built and tested in a Linux sandbox (the interpreter
logic, the IDE's UI, and the syntax highlighter were all run and verified
end-to-end). The one step that **must** happen on a real Windows PC is
turning this into a `.exe` — PyInstaller builds an executable for whatever
OS it runs on, so a Windows `.exe` has to be built on Windows.

## What's in this folder

```
indlan_ide/
├── indlan_ide.py              # the IDE app itself
├── indlan_ide.spec            # PyInstaller build recipe
├── build_exe.bat              # 1-click: builds dist\IndLanIDE.exe
├── register_ind_filetype.bat  # 1-click: gives .ind files the IndLan icon
├── unregister_ind_filetype.bat
├── indlan_icon.ico            # Windows icon (converted from your PNG)
├── indlan_icon.png
├── indlan_logo.png
├── lexer.py / ind_parser.py / ast_nodes.py / interpreter.py   # IndLan engine
├── indlan.py                  # original CLI/REPL entry point (still works)
├── examples_hindi.ind
├── examples_ifelse.ind
└── myprogram.ind
```

## Step 1 — Install Python (one-time, only needed to *build* the exe)

1. Go to https://python.org/downloads and install Python 3.10+ for Windows.
2. **Important:** on the first installer screen, check **"Add python.exe to PATH"**.
3. Tkinter is included automatically with the official Windows installer — no extra step.

## Step 2 — Build the exe

1. Copy this whole `indlan_ide` folder onto your Windows PC.
2. Double-click **`build_exe.bat`**.
   - It installs PyInstaller automatically, then builds the app.
   - First build takes 1-3 minutes.
3. When it finishes, your app is at:
   ```
   indlan_ide\dist\IndLanIDE.exe
   ```
   This single file can be copied anywhere — desktop, USB drive, another
   PC — and run without installing Python there too.

Double-click `IndLanIDE.exe` right now to try it — open `examples_hindi.ind`
from the File menu and press **Run** (or F5).

## Step 3 — Give `.ind` files the IndLan icon + double-click-to-open

1. Double-click **`register_ind_filetype.bat`** (in the same folder).
   - This only needs `dist\IndLanIDE.exe` to already exist (Step 2 done).
   - It registers the association **for your Windows user account** — no
     admin rights required.
2. If icons don't refresh immediately, the script offers a command to
   restart Explorer, or you can just sign out and back in.

Now any `.ind` file anywhere on your PC will show the IndLan icon, and
double-clicking it opens that file directly in IndLanIDE.exe.

To undo this later, run `unregister_ind_filetype.bat`.

## Using the IDE

| Action | How |
|---|---|
| New file | File → New, or `Ctrl+N` |
| Open file | File → Open, or `Ctrl+O` |
| Save | `Ctrl+S` |
| Save As | `Ctrl+Shift+S` |
| Run program | **▶ Run** button, or `F5` |
| Close tab | `Ctrl+W` |
| Keyword reference (English ↔ Hindi) | Help → Keyword Reference |

The bottom **OUTPUT** panel shows `print()`/`chhap()` output and any
lexer/parser/runtime errors with line numbers. If your program calls
`input()`, a text box appears at the bottom of the output panel — type
your answer and press Enter, same as a terminal prompt.

## Notes / limitations

- **Stop button**: IndLan programs run on a background thread so the UI
  never freezes, but there's no safe way to force-kill a Python thread
  mid-execution. Stop will only take effect at the next statement boundary
  (so an infinite tight loop, e.g. `while true { }`, can't currently be
  interrupted — close and reopen the app if that happens).
- **Building on Mac/Linux instead**: the same `indlan_ide.py` and `.spec`
  file work as-is on macOS/Linux with `pyinstaller indlan_ide.spec` — you'd
  just get a Mac/Linux executable instead of a `.exe`, and the file-icon
  association steps are OS-specific (the `.bat` registry scripts here are
  Windows-only).
- If Windows SmartScreen warns about the new exe ("Windows protected your
  PC") the first time you run it — that's normal for any unsigned new exe,
  not specific to this app. Click "More info" → "Run anyway".
