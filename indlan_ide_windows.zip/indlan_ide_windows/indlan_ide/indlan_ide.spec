# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for IndLan IDE.
# Build with:  pyinstaller indlan_ide.spec
# (must be run on Windows to produce a Windows .exe)

block_cipher = None

a = Analysis(
    ['indlan_ide.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('lexer.py', '.'),
        ('ind_parser.py', '.'),
        ('ast_nodes.py', '.'),
        ('interpreter.py', '.'),
        ('indlan_icon.ico', '.'),
        ('indlan_icon.png', '.'),
    ],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='IndLanIDE',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,        # set True temporarily if you need to see crash tracebacks
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='indlan_icon.ico',
)
