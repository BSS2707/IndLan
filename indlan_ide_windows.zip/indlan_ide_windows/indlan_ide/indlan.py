#!/usr/bin/env python3
"""
IndLan IDE
A desktop code editor for the IndLan programming language.
Built with Tkinter so it can be frozen into a single standalone .exe
with PyInstaller (no Python install required on the target machine).

Made for the IndLan project by Bhavya S Solanki.
"""

import sys
import os
import re
import io
import threading
import traceback
import contextlib

import tkinter as tk
from tkinter import ttk
from tkinter import filedialog, messagebox, font as tkfont

# ---------------------------------------------------------------------------
# Make sure the IndLan engine modules (lexer/parser/interpreter) are
# importable whether running from source or from a frozen PyInstaller exe.
# ---------------------------------------------------------------------------
if getattr(sys, "frozen", False):
    BASE_DIR = sys._MEIPASS  # PyInstaller temp extraction dir
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, BASE_DIR)

from lexer import tokenize, LexError
from ind_parser import parse, ParseError
from interpreter import Interpreter, IndLanRuntimeError


class RunStopped(Exception):
    """Raised inside the worker thread when the user clicks Stop while a
    program is blocked waiting for console input (aalao/input_*)."""
    pass


def resource_path(filename):
    """Resolve a bundled resource (icon, etc.) for both source and frozen runs."""
    return os.path.join(BASE_DIR, filename)


# ---------------------------------------------------------------------------
# Color theme (dark, VS Code-ish)
# ---------------------------------------------------------------------------
THEME = {
    "bg": "#1e1e2e",
    "editor_bg": "#1e1f29",
    "editor_fg": "#e6e6e6",
    "gutter_bg": "#181923",
    "gutter_fg": "#6c6f85",
    "select_bg": "#3a3f58",
    "cursor": "#ffffff",
    "toolbar_bg": "#15151f",
    "statusbar_bg": "#15151f",
    "statusbar_fg": "#9a9cb0",
    "console_bg": "#101018",
    "console_fg": "#d6d6e0",
    "console_err": "#ff6b6b",
    "accent": "#4fa3ff",
    "accent_green": "#2ecc71",
    "tab_bg": "#15151f",
    "tab_active_bg": "#1e1f29",
    "tab_fg": "#9a9cb0",
    "tab_active_fg": "#ffffff",
    # syntax colors
    "kw": "#ff79c6",        # control-flow / declaration keywords (English + Hindi)
    "builtin": "#4fa3ff",   # built-in functions
    "string": "#a3e07a",
    "number": "#f5a623",
    "comment": "#6c6f85",
    "operator": "#e6e6e6",
    "boollit": "#f5a623",
}

ENGLISH_KEYWORDS = [
    "let", "fun", "return", "if", "elif", "else", "while", "for", "in",
    "true", "false", "null", "and", "or", "not", "break", "continue",
    "import", "class", "new", "this", "do", "switch", "case", "default",
]

HINDI_KEYWORDS = [
    "maano", "kaam", "vapas", "agar", "nahito_agar", "nahito", "jabtak",
    "pratyek", "mein", "sahi", "galat", "khaali", "aur", "ya", "nahi",
    "roko", "jaari", "varg", "naya", "yeh", "karo", "vibhag", "sthiti",
    "anyatha",
]

BUILTIN_NAMES = [
    # I/O
    "print", "chhap", "input", "aalao", "input_int", "number_dalao", "input_float", "decimal_dalao", "input_bool", "haan_na",
    # type conversion
    "str", "int", "float", "bool", "char", "type",
    # collections
    "len", "range", "append", "pop", "insert", "remove", "reverse", "sort",
    "keys", "values", "has",
    # math
    "abs", "max", "min", "floor", "ceil", "round", "sqrt",
    # string methods (shown as builtins when used standalone)
    "upper", "lower", "strip", "lstrip", "rstrip", "split", "replace",
    "startswith", "endswith", "contains", "find",
]

ALL_KEYWORDS = ENGLISH_KEYWORDS + HINDI_KEYWORDS


# ---------------------------------------------------------------------------
# Syntax highlighter for the Text widget
# ---------------------------------------------------------------------------
class SyntaxHighlighter:
    TOKEN_RULES = [
        ("comment_block", re.compile(r"/\*.*?\*/", re.DOTALL)),
        ("comment_line", re.compile(r"//[^\n]*")),
        ("string", re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')),
        ("number", re.compile(r"\b\d+\.\d+\b|\b\d+\b")),
    ]

    KEYWORD_RE = re.compile(
        r"\b(" + "|".join(sorted(ALL_KEYWORDS, key=len, reverse=True)) + r")\b"
    )
    BUILTIN_RE = re.compile(
        r"\b(" + "|".join(sorted(BUILTIN_NAMES, key=len, reverse=True)) + r")\b"
    )

    def __init__(self, text_widget):
        self.text = text_widget
        self._configure_tags()
        self._job = None

    def _configure_tags(self):
        self.text.tag_configure("kw", foreground=THEME["kw"])
        self.text.tag_configure("builtin", foreground=THEME["builtin"])
        self.text.tag_configure("string", foreground=THEME["string"])
        self.text.tag_configure("number", foreground=THEME["number"])
        self.text.tag_configure("comment", foreground=THEME["comment"], font=("Consolas", 11, "italic"))

    def schedule(self, *_):
        # Debounce: cancel any pending highlight pass and queue a new one.
        if self._job is not None:
            self.text.after_cancel(self._job)
        self._job = self.text.after(120, self.highlight)

    def highlight(self):
        self._job = None
        content = self.text.get("1.0", "end-1c")
        for tag in ("kw", "builtin", "string", "number", "comment"):
            self.text.tag_remove(tag, "1.0", "end")

        # Mask out strings/comments first so keyword matching inside them is avoided.
        masked = content
        spans = {"string": [], "comment": []}

        def mask_spans(pattern, label):
            nonlocal masked
            out = []
            last = 0
            for m in pattern.finditer(masked):
                out.append(masked[last:m.start()])
                out.append(" " * (m.end() - m.start()))
                spans[label].append((m.start(), m.end()))
                last = m.end()
            out.append(masked[last:])
            masked = "".join(out)

        mask_spans(self.TOKEN_RULES[0][1], "comment")  # block comments
        mask_spans(self.TOKEN_RULES[1][1], "comment")  # line comments
        mask_spans(self.TOKEN_RULES[2][1], "string")   # strings

        for start, end in spans["string"]:
            self._apply(start, end, "string")
        for start, end in spans["comment"]:
            self._apply(start, end, "comment")

        for m in self.TOKEN_RULES[3][1].finditer(masked):
            self._apply(m.start(), m.end(), "number")

        for m in self.KEYWORD_RE.finditer(masked):
            self._apply(m.start(), m.end(), "kw")

        for m in self.BUILTIN_RE.finditer(masked):
            self._apply(m.start(), m.end(), "builtin")

    def _apply(self, start_idx, end_idx, tag):
        start = f"1.0+{start_idx}c"
        end = f"1.0+{end_idx}c"
        self.text.tag_add(tag, start, end)


# ---------------------------------------------------------------------------
# A single editor tab: line-number gutter + text widget
# ---------------------------------------------------------------------------
class EditorTab(ttk.Frame):
    def __init__(self, master, app, filepath=None, content=""):
        super().__init__(master)
        self.app = app
        self.filepath = filepath
        self.saved_content = content
        self._build_ui()
        self.text.insert("1.0", content)
        self.highlighter.highlight()
        self.text.edit_modified(False)

    def _build_ui(self):
        container = tk.Frame(self, bg=THEME["editor_bg"])
        container.pack(fill="both", expand=True)

        self.gutter = tk.Text(
            container, width=5, padx=6, pady=8, takefocus=0, border=0,
            background=THEME["gutter_bg"], foreground=THEME["gutter_fg"],
            state="disabled", wrap="none", font=("Consolas", 12),
        )
        self.gutter.pack(side="left", fill="y")

        editor_font = tkfont.Font(family="Consolas", size=12)
        self.text = tk.Text(
            container, undo=True, wrap="none", padx=8, pady=8, border=0,
            background=THEME["editor_bg"], foreground=THEME["editor_fg"],
            insertbackground=THEME["cursor"], selectbackground=THEME["select_bg"],
            font=editor_font, tabs=("1c",), maxundo=-1,
        )
        self.text.pack(side="left", fill="both", expand=True)

        vsb = ttk.Scrollbar(container, orient="vertical", command=self._on_scroll)
        vsb.pack(side="right", fill="y")
        self.text.configure(yscrollcommand=lambda a, b: self._sync_scroll(a, b, vsb))

        self.highlighter = SyntaxHighlighter(self.text)

        self.text.bind("<KeyRelease>", self._on_change)
        self.text.bind("<<Modified>>", self._on_modified_flag)
        self.text.bind("<MouseWheel>", lambda e: self.after_idle(self._update_gutter))
        self.text.bind("<Configure>", lambda e: self._update_gutter())
        self.text.bind("<Tab>", self._on_tab)

        self._update_gutter()

    def _on_tab(self, event):
        self.text.insert("insert", "    ")
        return "break"

    def _on_scroll(self, *args):
        self.text.yview(*args)
        self.gutter.yview(*args)

    def _sync_scroll(self, first, last, vsb):
        vsb.set(first, last)
        self.gutter.yview_moveto(first)

    def _on_modified_flag(self, event):
        if self.text.edit_modified():
            self.app.on_tab_dirty(self)

    def _on_change(self, event=None):
        self.highlighter.schedule()
        self._update_gutter()
        self.app.update_title()

    def _update_gutter(self):
        line_count = int(self.text.index("end-1c").split(".")[0])
        nums = "\n".join(str(i) for i in range(1, line_count + 1))
        self.gutter.configure(state="normal")
        self.gutter.delete("1.0", "end")
        self.gutter.insert("1.0", nums)
        self.gutter.configure(state="disabled")
        self.gutter.yview_moveto(self.text.yview()[0])

    def get_content(self):
        return self.text.get("1.0", "end-1c")

    def is_dirty(self):
        return self.get_content() != self.saved_content

    def mark_saved(self):
        self.saved_content = self.get_content()
        self.text.edit_modified(False)

    def display_name(self):
        base = os.path.basename(self.filepath) if self.filepath else "untitled.ind"
        return ("● " if self.is_dirty() else "") + base


# ---------------------------------------------------------------------------
# Output console: shows stdout / stdin-prompt-driven input / errors
# ---------------------------------------------------------------------------
class Console(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=THEME["console_bg"])
        header = tk.Frame(self, bg=THEME["console_bg"])
        header.pack(side="top", fill="x")
        tk.Label(
            header, text="OUTPUT", bg=THEME["console_bg"], fg=THEME["statusbar_fg"],
            font=("Segoe UI", 9, "bold"), anchor="w", padx=8, pady=4,
        ).pack(side="left")
        self.clear_btn = tk.Button(
            header, text="Clear", command=self.clear, bg=THEME["console_bg"],
            fg=THEME["statusbar_fg"], border=0, activebackground=THEME["console_bg"],
            activeforeground=THEME["accent"], font=("Segoe UI", 9),
        )
        self.clear_btn.pack(side="right", padx=6)

        # Input line for IndLan's input() builtin. IMPORTANT: this is packed
        # with side="bottom" and BEFORE the scrolling output body below, so
        # it always reserves its own space in the console pane and can never
        # get squeezed to 0px / unmapped when the pane is resized short
        # (this was the root cause of the input box "disappearing" while a
        # program was paused on aalao()/input()).
        input_row = tk.Frame(self, bg=THEME["console_bg"], highlightthickness=1,
                              highlightbackground=THEME["console_bg"])
        input_row.pack(side="bottom", fill="x")
        self._input_row = input_row
        self.waiting_label = tk.Label(
            self, text="⏳ Waiting for input — type below and press Enter",
            bg=THEME["console_bg"], fg=THEME["accent"], font=("Segoe UI", 9, "italic"),
            anchor="w", padx=8, pady=2,
        )
        # waiting_label is only packed (shown) while a request_input() call
        # is pending; it's not packed at start so it takes no space normally.
        self.prompt_lbl = tk.Label(
            input_row, text=">>>", bg=THEME["console_bg"], fg=THEME["accent"],
            font=("Consolas", 11, "bold"), padx=8,
        )
        self.prompt_lbl.pack(side="left")
        self.input_var = tk.StringVar()
        self.input_entry = tk.Entry(
            input_row, textvariable=self.input_var, background="#1a1a24",
            foreground=THEME["console_fg"], insertbackground=THEME["console_fg"],
            border=0, font=("Consolas", 11),
        )
        self.input_entry.pack(side="left", fill="x", expand=True, padx=(0, 8), pady=6)
        self.input_entry.bind("<Return>", self._submit_input)
        self._pending_input = None  # threading.Event-coordinated value holder

        body = tk.Frame(self, bg=THEME["console_bg"])
        body.pack(side="top", fill="both", expand=True)

        self.text = tk.Text(
            body, background=THEME["console_bg"], foreground=THEME["console_fg"],
            font=("Consolas", 11), padx=8, pady=6, border=0, wrap="word", state="disabled",
            height=6,  # sane default; actual size is governed by the pane, not this
        )
        self.text.pack(side="left", fill="both", expand=True)
        self.text.tag_configure("err", foreground=THEME["console_err"])
        self.text.tag_configure("ok", foreground=THEME["accent_green"])
        self.text.tag_configure("info", foreground=THEME["statusbar_fg"])

        vsb = ttk.Scrollbar(body, orient="vertical", command=self.text.yview)
        vsb.pack(side="right", fill="y")
        self.text.configure(yscrollcommand=vsb.set)

        self.set_input_enabled(False)

    def set_input_enabled(self, enabled):
        self.input_entry.configure(state=("normal" if enabled else "disabled"))
        if enabled:
            self._input_row.configure(highlightbackground=THEME["accent"], highlightthickness=1)
            self.waiting_label.pack(side="bottom", fill="x", before=self._input_row)
        else:
            self._input_row.configure(highlightbackground=THEME["console_bg"])
            self.waiting_label.pack_forget()

    def _submit_input(self, event=None):
        if self._pending_input is not None:
            value = self.input_var.get()
            self.write(value + "\n", "info")
            self.input_var.set("")
            ev, box = self._pending_input
            box["value"] = value
            box["stopped"] = False
            ev.set()

    def cancel_pending_input(self):
        """Called from the main thread (Stop button) to unblock a worker
        thread that is currently stuck waiting inside request_input()."""
        if self._pending_input is not None:
            ev, box = self._pending_input
            box["value"] = ""
            box["stopped"] = True
            ev.set()

    def request_input(self):
        """Called from the worker thread. Blocks until the user submits a
        line, or until cancel_pending_input() is called (e.g. Stop)."""
        ev = threading.Event()
        box = {}
        self._pending_input = (ev, box)
        self.after(0, lambda: self.set_input_enabled(True))
        self.after(0, lambda: self.input_entry.focus_set())
        ev.wait()
        self.after(0, lambda: self.set_input_enabled(False))
        self._pending_input = None
        if box.get("stopped"):
            raise RunStopped()
        return box["value"]

    def write(self, s, tag=None):
        self.text.configure(state="normal")
        if tag:
            self.text.insert("end", s, tag)
        else:
            self.text.insert("end", s)
        self.text.see("end")
        self.text.configure(state="disabled")

    def clear(self):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.configure(state="disabled")


# ---------------------------------------------------------------------------
# Stream wrapper: redirects print()/input() into the Console widget
# ---------------------------------------------------------------------------
class ConsoleStdout(io.TextIOBase):
    def __init__(self, console, app):
        self.console = console
        self.app = app

    def write(self, s):
        if s:
            self.app.root.after(0, lambda: self.console.write(s))
        return len(s)

    def flush(self):
        pass


class ConsoleStdin(io.TextIOBase):
    def __init__(self, console):
        self.console = console

    def readline(self, *args):
        return self.console.request_input() + "\n"


# ---------------------------------------------------------------------------
# Main application
# ---------------------------------------------------------------------------
class IndLanIDE:
    APP_TITLE = "IndLan IDE"

    def __init__(self, root):
        self.root = root
        self.tabs = {}  # frame -> EditorTab
        self.run_thread = None
        self._build_ui()
        self.new_file()

    # ---------------- UI construction ----------------

    def _build_ui(self):
        self.root.title(self.APP_TITLE)
        self.root.geometry("1200x760")
        self.root.configure(bg=THEME["bg"])

        try:
            icon_path = resource_path("indlan_icon.ico")
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except Exception:
            pass

        self._build_menu()
        self._build_toolbar()

        body = tk.Frame(self.root, bg=THEME["bg"])
        body.pack(fill="both", expand=True)

        # Tab bar + editor area (top) and console (bottom), resizable split
        self.paned = tk.PanedWindow(body, orient="vertical", bg=THEME["bg"], sashwidth=6, bd=0)
        self.paned.pack(fill="both", expand=True)

        editor_area = tk.Frame(self.paned, bg=THEME["bg"])
        self._build_tabbar(editor_area)
        self.notebook_host = tk.Frame(editor_area, bg=THEME["editor_bg"])
        self.notebook_host.pack(fill="both", expand=True)
        self.paned.add(editor_area, stretch="always", minsize=200)

        self.console = Console(self.paned)
        self.paned.add(self.console, minsize=120)
        self.root.after(50, lambda: self.paned.paneconfigure(self.console, height=220))

        self._build_statusbar()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.bind_all("<Control-n>", lambda e: self.new_file())
        self.root.bind_all("<Control-o>", lambda e: self.open_file())
        self.root.bind_all("<Control-s>", lambda e: self.save_file())
        self.root.bind_all("<Control-Shift-S>", lambda e: self.save_file_as())
        self.root.bind_all("<F5>", lambda e: self.run_code())
        self.root.bind_all("<Control-w>", lambda e: self.close_current_tab())

    def _build_menu(self):
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New File", accelerator="Ctrl+N", command=self.new_file)
        file_menu.add_command(label="Open File...", accelerator="Ctrl+O", command=self.open_file)
        file_menu.add_command(label="Save", accelerator="Ctrl+S", command=self.save_file)
        file_menu.add_command(label="Save As...", accelerator="Ctrl+Shift+S", command=self.save_file_as)
        file_menu.add_separator()
        file_menu.add_command(label="Close Tab", accelerator="Ctrl+W", command=self.close_current_tab)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        run_menu = tk.Menu(menubar, tearoff=0)
        run_menu.add_command(label="Run", accelerator="F5", command=self.run_code)
        run_menu.add_command(label="Stop", command=self.stop_code)
        menubar.add_cascade(label="Run", menu=run_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="Keyword Reference", command=self.show_keywords)
        help_menu.add_command(label="About IndLan IDE", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.root.config(menu=menubar)

    def _build_toolbar(self):
        bar = tk.Frame(self.root, bg=THEME["toolbar_bg"], height=40)
        bar.pack(fill="x")

        def tbtn(text, cmd, fg=THEME["editor_fg"]):
            b = tk.Button(
                bar, text=text, command=cmd, bg=THEME["toolbar_bg"], fg=fg,
                activebackground="#23243a", activeforeground=fg, border=0,
                font=("Segoe UI", 10), padx=10, pady=6, cursor="hand2",
            )
            b.pack(side="left")
            return b

        tbtn("▶  Run", self.run_code, fg=THEME["accent_green"])
        tbtn("■  Stop", self.stop_code, fg=THEME["console_err"])
        sep = tk.Frame(bar, bg="#2a2b3d", width=1)
        sep.pack(side="left", fill="y", pady=6, padx=4)
        tbtn("Open", self.open_file)
        tbtn("Save", self.save_file)
        tbtn("New", self.new_file)

        self.run_status_lbl = tk.Label(
            bar, text="Ready", bg=THEME["toolbar_bg"], fg=THEME["statusbar_fg"], font=("Segoe UI", 9)
        )
        self.run_status_lbl.pack(side="right", padx=12)

    def _build_tabbar(self, parent):
        self.tabbar = tk.Frame(parent, bg=THEME["tab_bg"], height=32)
        self.tabbar.pack(fill="x")
        self.tab_buttons = {}  # frame -> button widget
        self.active_tab = None

    def _build_statusbar(self):
        bar = tk.Frame(self.root, bg=THEME["statusbar_bg"], height=24)
        bar.pack(fill="x", side="bottom")
        self.status_lbl = tk.Label(
            bar, text="IndLan IDE ready.", bg=THEME["statusbar_bg"], fg=THEME["statusbar_fg"],
            font=("Segoe UI", 9), anchor="w", padx=10,
        )
        self.status_lbl.pack(side="left")
        self.path_lbl = tk.Label(
            bar, text="", bg=THEME["statusbar_bg"], fg=THEME["statusbar_fg"],
            font=("Segoe UI", 9), anchor="e", padx=10,
        )
        self.path_lbl.pack(side="right")

    # ---------------- tab management ----------------

    def _make_tab_button(self, tab_frame, tab):
        btn_frame = tk.Frame(self.tabbar, bg=THEME["tab_bg"])
        lbl = tk.Label(
            btn_frame, text=tab.display_name(), bg=THEME["tab_bg"], fg=THEME["tab_fg"],
            font=("Segoe UI", 10), padx=10, pady=6, cursor="hand2",
        )
        lbl.pack(side="left")
        close_lbl = tk.Label(
            btn_frame, text="×", bg=THEME["tab_bg"], fg=THEME["tab_fg"],
            font=("Segoe UI", 10), padx=6, cursor="hand2",
        )
        close_lbl.pack(side="left")
        btn_frame.pack(side="left")

        lbl.bind("<Button-1>", lambda e: self.activate_tab(tab_frame))
        close_lbl.bind("<Button-1>", lambda e: self.close_tab(tab_frame))

        self.tab_buttons[tab_frame] = (btn_frame, lbl, close_lbl)
        return btn_frame

    def _refresh_tab_visuals(self):
        for frame, (btn_frame, lbl, close_lbl) in self.tab_buttons.items():
            tab = self.tabs[frame]
            active = frame is self.active_tab
            bg = THEME["tab_active_bg"] if active else THEME["tab_bg"]
            fg = THEME["tab_active_fg"] if active else THEME["tab_fg"]
            btn_frame.configure(bg=bg)
            lbl.configure(text=tab.display_name(), bg=bg, fg=fg)
            close_lbl.configure(bg=bg, fg=fg)

    def new_file(self):
        tab = EditorTab(self.notebook_host, self, filepath=None, content="")
        frame = tab
        self.tabs[frame] = tab
        self._make_tab_button(frame, tab)
        self.activate_tab(frame)

    def open_file(self):
        path = filedialog.askopenfilename(
            title="Open IndLan File",
            filetypes=[("IndLan files", "*.ind"), ("All files", "*.*")],
        )
        if not path:
            return
        self.open_path(path)

    def open_path(self, path):
        # If already open, just activate it.
        for frame, tab in self.tabs.items():
            if tab.filepath and os.path.abspath(tab.filepath) == os.path.abspath(path):
                self.activate_tab(frame)
                return
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            messagebox.showerror("Open File", f"Could not open file:\n{e}")
            return

        tab = EditorTab(self.notebook_host, self, filepath=path, content=content)
        frame = tab
        self.tabs[frame] = tab
        self._make_tab_button(frame, tab)
        self.activate_tab(frame)

        # Close the initial blank "untitled" tab if it's empty and unused.
        self._maybe_close_blank_starter(frame)

    def _maybe_close_blank_starter(self, just_opened_frame):
        for frame, tab in list(self.tabs.items()):
            if frame is just_opened_frame:
                continue
            if tab.filepath is None and tab.get_content() == "" and len(self.tabs) > 1:
                self.close_tab(frame, confirm=False)

    def activate_tab(self, frame):
        for f in self.tabs:
            self.tabs[f].pack_forget()
        self.tabs[frame].pack(fill="both", expand=True)
        self.active_tab = frame
        self._refresh_tab_visuals()
        self.update_title()

    def close_current_tab(self):
        if self.active_tab:
            self.close_tab(self.active_tab)

    def close_tab(self, frame, confirm=True):
        tab = self.tabs.get(frame)
        if tab is None:
            return
        if confirm and tab.is_dirty():
            res = messagebox.askyesnocancel(
                "Unsaved changes",
                f"Save changes to {os.path.basename(tab.filepath) if tab.filepath else 'untitled.ind'}?",
            )
            if res is None:
                return
            if res:
                if not self._save_tab(tab):
                    return

        btn_frame, _, _ = self.tab_buttons.pop(frame)
        btn_frame.destroy()
        frame.destroy()
        del self.tabs[frame]

        if not self.tabs:
            self.new_file()
            return

        if self.active_tab is frame or self.active_tab not in self.tabs:
            self.activate_tab(next(iter(self.tabs)))

    def on_tab_dirty(self, tab):
        self._refresh_tab_visuals()
        self.update_title()

    def current_tab(self):
        return self.tabs.get(self.active_tab)

    def update_title(self):
        tab = self.current_tab()
        if tab is None:
            self.root.title(self.APP_TITLE)
            return
        name = os.path.basename(tab.filepath) if tab.filepath else "untitled.ind"
        dirty = "● " if tab.is_dirty() else ""
        self.root.title(f"{dirty}{name} — {self.APP_TITLE}")
        self.path_lbl.configure(text=tab.filepath or "(unsaved)")
        self._refresh_tab_visuals()

    # ---------------- save / load ----------------

    def save_file(self):
        tab = self.current_tab()
        if tab is None:
            return
        self._save_tab(tab)

    def _save_tab(self, tab):
        if tab.filepath is None:
            return self._save_tab_as(tab)
        try:
            with open(tab.filepath, "w", encoding="utf-8") as f:
                f.write(tab.get_content())
            tab.mark_saved()
            self.update_title()
            self.status_lbl.configure(text=f"Saved {os.path.basename(tab.filepath)}")
            return True
        except Exception as e:
            messagebox.showerror("Save File", f"Could not save file:\n{e}")
            return False

    def save_file_as(self):
        tab = self.current_tab()
        if tab is None:
            return
        self._save_tab_as(tab)

    def _save_tab_as(self, tab):
        path = filedialog.asksaveasfilename(
            title="Save IndLan File",
            defaultextension=".ind",
            filetypes=[("IndLan files", "*.ind"), ("All files", "*.*")],
        )
        if not path:
            return False
        tab.filepath = path
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(tab.get_content())
            tab.mark_saved()
            self.update_title()
            self.status_lbl.configure(text=f"Saved {os.path.basename(path)}")
            return True
        except Exception as e:
            messagebox.showerror("Save File", f"Could not save file:\n{e}")
            return False

    # ---------------- run ----------------

    def run_code(self):
        if self.run_thread is not None and self.run_thread.is_alive():
            self.status_lbl.configure(text="A program is already running.")
            return
        tab = self.current_tab()
        if tab is None:
            return
        source = tab.get_content()
        self.console.clear()
        self.console.write(f"Running {tab.display_name().lstrip('● ')} ...\n\n", "info")
        self.run_status_lbl.configure(text="Running...", fg=THEME["accent"])

        self.run_thread = threading.Thread(target=self._run_worker, args=(source,), daemon=True)
        self.run_thread.start()

    def _run_worker(self, source):
        old_stdout, old_stdin, old_stderr = sys.stdout, sys.stdin, sys.stderr
        sys.stdout = ConsoleStdout(self.console, self)
        sys.stderr = ConsoleStdout(self.console, self)
        sys.stdin = ConsoleStdin(self.console)
        try:
            tokens = tokenize(source)
            program = parse(tokens)
            interpreter = Interpreter()
            interpreter.run(program)
            self.root.after(0, lambda: self.console.write("\nProgram finished.\n", "ok"))
        except RunStopped:
            self.root.after(0, lambda: self.console.write("\n[Program stopped by user.]\n", "info"))
        except LexError as e:
            msg = str(e)
            self.root.after(0, lambda: self.console.write(f"\n{msg}\n", "err"))
        except ParseError as e:
            msg = str(e)
            self.root.after(0, lambda: self.console.write(f"\n{msg}\n", "err"))
        except IndLanRuntimeError as e:
            msg = str(e)
            self.root.after(0, lambda: self.console.write(f"\n{msg}\n", "err"))
        except Exception:
            tb = traceback.format_exc()
            self.root.after(0, lambda: self.console.write(f"\nUnexpected error:\n{tb}\n", "err"))
        finally:
            sys.stdout, sys.stdin, sys.stderr = old_stdout, old_stdin, old_stderr
            self.root.after(0, lambda: self.run_status_lbl.configure(text="Ready", fg=THEME["statusbar_fg"]))

    def stop_code(self):
        # Plain threads can't be force-killed safely, so a Stop click can't
        # interrupt arbitrary running code (e.g. a tight loop). What it CAN
        # do, and now does, is unblock a program that is paused waiting on
        # aalao()/input() — previously Stop did nothing in that situation,
        # which made a paused program look permanently frozen.
        if self.run_thread is not None and self.run_thread.is_alive():
            if self.console._pending_input is not None:
                self.console.cancel_pending_input()
            else:
                self.console.write(
                    "\n[Stop requested — the program will stop after its current statement; "
                    "long-running loops cannot be force-killed.]\n", "info"
                )
        else:
            self.status_lbl.configure(text="Nothing is running.")

    # ---------------- help ----------------

    def show_keywords(self):
        win = tk.Toplevel(self.root)
        win.title("IndLan Keyword Reference")
        win.geometry("620x820")
        win.configure(bg=THEME["bg"])
        text = tk.Text(win, bg=THEME["editor_bg"], fg=THEME["editor_fg"], font=("Consolas", 11), padx=12, pady=12)
        text.pack(fill="both", expand=True)
        kw_rows = [
            ("let", "maano", "declare a variable"),
            ("fun", "kaam", "declare a function"),
            ("return", "vapas", "return a value"),
            ("if", "agar", "conditional"),
            ("elif", "nahito_agar", "else-if branch"),
            ("else", "nahito", "else branch"),
            ("while", "jabtak", "while loop"),
            ("do", "karo", "do (in do-while)"),
            ("for", "pratyek", "for-each loop"),
            ("in", "mein", "used in for-loops"),
            ("switch", "vibhag", "switch statement"),
            ("case", "sthiti", "switch case"),
            ("default", "anyatha", "switch default"),
            ("class", "varg", "declare a class"),
            ("new", "naya", "instantiate a class"),
            ("this", "yeh", "current instance"),
            ("true", "sahi", "boolean true"),
            ("false", "galat", "boolean false"),
            ("null", "khaali", "null value"),
            ("and", "aur", "logical and"),
            ("or", "ya", "logical or"),
            ("not", "nahi", "logical not"),
            ("break", "roko", "break out of a loop"),
            ("continue", "jaari", "continue to next iteration"),
        ]
        builtin_rows = [
            ("print / chhap(v...)", "print values to output"),
            ("input(prompt?)", "read a string from user"),
            ("input_int(prompt?)", "read an integer from user"),
            ("input_float(prompt?)", "read a float from user"),
            ("input_bool(prompt?)", "read true/false from user"),
            ("str(v)", "convert to string"),
            ("int(v)", "convert to integer"),
            ("float(v)", "convert to float"),
            ("bool(v)", "convert to boolean"),
            ("char(v)", "int->char or char->int (ord)"),
            ("type(v)", "return type name as string"),
            ("len(v)", "length of string/list/dict"),
            ("range(n) / range(a,b,s)", "list of integers"),
            ("append(lst, v)", "add v to end of list"),
            ("pop(lst, i?)", "remove & return last (or i-th)"),
            ("insert(lst, i, v)", "insert v at index i"),
            ("remove(lst, v)", "remove first occurrence of v"),
            ("reverse(lst)", "reverse list in place"),
            ("sort(lst)", "sort list in place"),
            ("keys(d) / values(d)", "dict keys or values as list"),
            ("has(col, v)", "check if v in list/dict/string"),
            ("abs(n)", "absolute value"),
            ("max(a,b,...) / min(a,b,...)", "max or min value"),
            ("floor(n) / ceil(n)", "round down / up to integer"),
            ("round(n, digits?)", "round to nearest"),
            ("sqrt(n)", "square root"),
        ]
        op_rows = [
            ("**", "exponentiation  (2 ** 8 = 256)"),
            ('f"...{expr}..."', "f-string interpolation"),
            ("str * int", 'string repetition  ("ha" * 3)'),
            ("lst[-1]", "negative index (last element)"),
            ("s.upper() .lower() .strip()", "string methods"),
            ("s.replace(a,b) .split() .find(x)", "more string methods"),
            ("lst.append(v) .pop() .sort()", "list methods"),
        ]
        text.insert("end", "── KEYWORDS ──────────────────────────────────────\n")
        text.insert("end", f"{'English':<18}{'Hindi':<18}Meaning\n")
        text.insert("end", "-" * 54 + "\n")
        for en, hi, meaning in kw_rows:
            text.insert("end", f"{en:<18}{hi:<18}{meaning}\n")
        text.insert("end", "\n── BUILT-IN FUNCTIONS ────────────────────────────\n")
        text.insert("end", f"{'Function':<28}Description\n")
        text.insert("end", "-" * 54 + "\n")
        for fn, desc in builtin_rows:
            text.insert("end", f"{fn:<28}{desc}\n")
        text.insert("end", "\n── OPERATORS & EXTRAS ────────────────────────────\n")
        text.insert("end", f"{'Syntax':<28}Description\n")
        text.insert("end", "-" * 54 + "\n")
        for syn, desc in op_rows:
            text.insert("end", f"{syn:<28}{desc}\n")
        text.configure(state="disabled")

    def show_about(self):
        messagebox.showinfo(
            "About IndLan IDE",
            "IndLan IDE\n\n"
            "A desktop editor and runner for the IndLan programming language.\n"
            "Supports English and Hindi-style keywords.\n\n"
            "IndLan made by Bhavya S Solanki.",
        )

    # ---------------- lifecycle ----------------

    def on_close(self):
        dirty_tabs = [t for t in self.tabs.values() if t.is_dirty()]
        if dirty_tabs:
            res = messagebox.askyesnocancel("Unsaved changes", "You have unsaved changes. Save before exiting?")
            if res is None:
                return
            if res:
                for t in dirty_tabs:
                    if not self._save_tab(t):
                        return
        self.root.destroy()


def main():
    root = tk.Tk()
    try:
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background=THEME["editor_bg"])
        style.configure("Vertical.TScrollbar", background=THEME["tab_bg"], troughcolor=THEME["bg"], arrowcolor=THEME["tab_fg"])
    except Exception:
        pass

    app = IndLanIDE(root)

    # If a .ind file was passed as an argument (e.g. via "Open with" or
    # double-clicking a .ind file once it's associated), open it.
    if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        app.open_path(sys.argv[1])

    root.mainloop()


if __name__ == "__main__":
    main()