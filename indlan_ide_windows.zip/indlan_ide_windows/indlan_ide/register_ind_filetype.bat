@echo off
REM ============================================================
REM  register_ind_filetype.bat
REM  Associates .ind files with IndLan IDE and gives them the
REM  IndLan icon in File Explorer. Double-clicking a .ind file
REM  will open it in IndLanIDE.exe.
REM
REM  Run this AFTER build_exe.bat has created dist\IndLanIDE.exe.
REM  Right-click this file -> "Run as administrator" is recommended,
REM  but a per-user (HKCU) registration also works without admin.
REM ============================================================

setlocal
set "EXE_PATH=%~dp0dist\IndLanIDE.exe"
set "ICO_PATH=%~dp0indlan_icon.ico"

if not exist "%EXE_PATH%" (
    echo [ERROR] Could not find "%EXE_PATH%"
    echo Run build_exe.bat first to create dist\IndLanIDE.exe
    pause
    exit /b 1
)

echo Registering .ind file type for the current user...
echo   EXE: %EXE_PATH%
echo   ICON: %ICO_PATH%
echo.

REM Associate the .ind extension with a ProgID
reg add "HKCU\Software\Classes\.ind" /ve /d "IndLan.SourceFile" /f >nul

REM Define the ProgID: display name, icon, and open command
reg add "HKCU\Software\Classes\IndLan.SourceFile" /ve /d "IndLan Source File" /f >nul
reg add "HKCU\Software\Classes\IndLan.SourceFile\DefaultIcon" /ve /d "\"%ICO_PATH%\",0" /f >nul
reg add "HKCU\Software\Classes\IndLan.SourceFile\shell\open\command" /ve /d "\"%EXE_PATH%\" \"%%1\"" /f >nul

REM Refresh Explorer icons
ie4uinit.exe -show >nul 2>nul

echo.
echo Done! .ind files will now show the IndLan icon.
echo You may need to log off/on, or restart Explorer, for icons
echo to refresh everywhere (Windows caches file icons).
echo.
echo To restart Explorer now and force the icon refresh, run:
echo   taskkill /f /im explorer.exe ^&^& start explorer.exe
echo.
pause
