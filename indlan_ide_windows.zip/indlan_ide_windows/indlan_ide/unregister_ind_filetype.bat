@echo off
REM Removes the .ind file association created by register_ind_filetype.bat

echo Removing .ind file association for the current user...
reg delete "HKCU\Software\Classes\.ind" /f >nul 2>nul
reg delete "HKCU\Software\Classes\IndLan.SourceFile" /f >nul 2>nul
ie4uinit.exe -show >nul 2>nul

echo Done. .ind files will revert to their previous default (likely plain text/Notepad).
pause
