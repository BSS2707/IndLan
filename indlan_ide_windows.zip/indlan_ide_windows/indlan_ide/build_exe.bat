@echo off
REM ============================================================
REM  build_exe.bat
REM  Builds IndLanIDE.exe from source using PyInstaller.
REM  Run this on WINDOWS, inside the indlan_ide folder, with
REM  Python already installed (python.org, "Add to PATH" checked).
REM ============================================================

echo.
echo === IndLan IDE - Windows EXE Builder ===
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found on PATH.
    echo Install Python from https://python.org and re-run this script.
    pause
    exit /b 1
)

echo Installing PyInstaller (if not already installed)...
python -m pip install --upgrade pyinstaller

echo.
echo Building IndLanIDE.exe ...
python -m PyInstaller indlan_ide.spec --clean --noconfirm

echo.
if exist dist\IndLanIDE.exe (
    echo SUCCESS! Your exe is here:
    echo   %cd%\dist\IndLanIDE.exe
    echo.
    echo You can copy dist\IndLanIDE.exe anywhere on your PC and run it directly.
) else (
    echo Build did not produce an exe - scroll up for errors.
)

echo.
pause
