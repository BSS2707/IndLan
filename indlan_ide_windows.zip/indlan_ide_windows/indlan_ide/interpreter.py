"""
IndLan Interpreter
A tree-walking interpreter that executes the AST produced by the parser.
"""

from ast_nodes import *
from lexer import tokenize, LexError
from ind_parser import parse, ParseError


class IndLanRuntimeError(Exception):
    def __init__(self, message, line=None):
        loc = f"[Line {line}] " if line is not None else ""
        super().__init__(f"{loc}Runtime Error: {message}")
        self.line = line


class BreakSignal(Exception):
    pass

class ContinueSignal(Exception):
    pass

class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value


class Environment:
    """A single lexical scope, chained to its parent (closures!)."""

    def __init__(self, parent=None):
        self.vars = {}
        self.parent = parent

    def define(self, name, value):
        self.vars[name] = value

    def get(self, name, line=None):
        env = self
        while env is not None:
            if name in env.vars:
                return env.vars[name]
            env = env.parent
        raise IndLanRuntimeError(f"Undefined variable '{name}'", line)

    def set(self, name, value, line=None):
        env = self
        while env is not None:
            if name in env.vars:
                env.vars[name] = value
                return
            env = env.parent
        raise IndLanRuntimeError(f"Cannot assign to undefined variable '{name}'", line)

    def has(self, name):
        env = self
        while env is not None:
            if name in env.vars:
                return True
            env = env.parent
        return False


class IndFunction:
    """A user-defined function (also used for class methods)."""

    def __init__(self, name, params, body, closure, interpreter, this_binding=None):
        self.name = name
        self.params = params
        self.body = body
        self.closure = closure
        self.interpreter = interpreter
        self.this_binding = this_binding

    def bind(self, instance):
        return IndFunction(self.name, self.params, self.body, self.closure, self.interpreter, this_binding=instance)

    def call(self, args, line):
        if len(args) != len(self.params):
            raise IndLanRuntimeError(
                f"Function '{self.name}' expects {len(self.params)} argument(s), got {len(args)}", line
            )
        env = Environment(self.closure)
        if self.this_binding is not None:
            env.define("this", self.this_binding)
        for param, arg in zip(self.params, args):
            env.define(param, arg)
        try:
            self.interpreter.exec_block(self.body, env)
        except ReturnSignal as r:
            return r.value
        return None

    def __repr__(self):
        return f"<function {self.name}>"


class IndClass:
    def __init__(self, name, methods):
        self.name = name
        self.methods = methods  # dict: name -> IndFunction (unbound)

    def find_method(self, name):
        return self.methods.get(name)

    def __repr__(self):
        return f"<class {self.name}>"


class IndInstance:
    def __init__(self, klass):
        self.klass = klass
        self.fields = {}

    def get(self, name, line=None):
        if name in self.fields:
            return self.fields[name]
        method = self.klass.find_method(name)
        if method is not None:
            return method.bind(self)
        raise IndLanRuntimeError(f"'{self.klass.name}' has no property '{name}'", line)

    def set(self, name, value):
        self.fields[name] = value

    def __repr__(self):
        return f"<{self.klass.name} instance>"


class Interpreter:
    def __init__(self):
        self.globals = Environment()
        self.setup_builtins()

    # ---------- built-ins ----------

    def setup_builtins(self):
        interp = self

        def ind_print(args, line):
            print(*[interp.stringify(a) for a in args])
            return None

        def ind_len(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("len() expects exactly 1 argument", line)
            val = args[0]
            if isinstance(val, (str, list, dict)):
                return len(val)
            raise IndLanRuntimeError(f"len() not supported for this type", line)

        def ind_range(args, line):
            if len(args) == 1:
                return list(range(int(args[0])))
            if len(args) == 2:
                return list(range(int(args[0]), int(args[1])))
            if len(args) == 3:
                return list(range(int(args[0]), int(args[1]), int(args[2])))
            raise IndLanRuntimeError("range() expects 1 to 3 arguments", line)

        def ind_str(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("str() expects 1 argument", line)
            return interp.stringify(args[0])

        def ind_int(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("int() expects 1 argument", line)
            try:
                v = args[0]
                if isinstance(v, bool):
                    return 1 if v else 0
                return int(v)
            except (ValueError, TypeError):
                raise IndLanRuntimeError(f"Cannot convert to int: {args[0]!r}", line)

        def ind_float(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("float() expects 1 argument", line)
            try:
                return float(args[0])
            except (ValueError, TypeError):
                raise IndLanRuntimeError(f"Cannot convert to float: {args[0]!r}", line)

        def ind_bool(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("bool() expects 1 argument", line)
            return interp.truthy(args[0])

        def ind_char(args, line):
            """char(65) -> 'A'  /  char('A') -> 65 (ord)"""
            if len(args) != 1:
                raise IndLanRuntimeError("char() expects 1 argument", line)
            v = args[0]
            if isinstance(v, int):
                return chr(v)
            if isinstance(v, str) and len(v) == 1:
                return ord(v)
            raise IndLanRuntimeError("char() expects an int (-> character) or single-character string (-> int)", line)

        def _read_line(prompt):
            import sys
            if prompt:
                sys.stdout.write(prompt)
                sys.stdout.flush()
            return sys.stdin.readline().rstrip("\n")

        def ind_input(args, line):
            prompt = interp.stringify(args[0]) if args else ""
            return _read_line(prompt)

        def ind_input_int(args, line):
            prompt = interp.stringify(args[0]) if args else ""
            raw = _read_line(prompt)
            try:
                return int(raw.strip())
            except ValueError:
                raise IndLanRuntimeError(f"number_dalao/input_int(): could not convert '{raw}' to int", line)

        def ind_input_float(args, line):
            prompt = interp.stringify(args[0]) if args else ""
            raw = _read_line(prompt)
            try:
                return float(raw.strip())
            except ValueError:
                raise IndLanRuntimeError(f"decimal_dalao/input_float(): could not convert '{raw}' to float", line)

        def ind_input_bool(args, line):
            prompt = interp.stringify(args[0]) if args else ""
            raw = _read_line(prompt).strip().lower()
            if raw in ("true", "sahi", "1", "yes", "ha", "haan"):
                return True
            if raw in ("false", "galat", "0", "no", "nahi"):
                return False
            raise IndLanRuntimeError(
                f"haan_na/input_bool(): expected true/false (or sahi/galat), got '{raw}'", line)

        def ind_type(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("type() expects 1 argument", line)
            v = args[0]
            if isinstance(v, bool): return "bool"
            if isinstance(v, int): return "int"
            if isinstance(v, float): return "float"
            if isinstance(v, str): return "string"
            if isinstance(v, list): return "list"
            if isinstance(v, dict): return "dict"
            if v is None: return "null"
            if isinstance(v, IndInstance): return v.klass.name
            if isinstance(v, IndFunction): return "function"
            if isinstance(v, IndClass): return "class"
            return "unknown"

        def ind_append(args, line):
            if len(args) != 2:
                raise IndLanRuntimeError("append() expects 2 arguments: list, value", line)
            lst, val = args[0], args[1]
            if not isinstance(lst, list):
                raise IndLanRuntimeError("append() expects a list as first argument", line)
            lst.append(val)
            return lst

        def ind_pop(args, line):
            if not args:
                raise IndLanRuntimeError("pop() expects at least 1 argument", line)
            lst = args[0]
            if not isinstance(lst, list):
                raise IndLanRuntimeError("pop() expects a list", line)
            if len(lst) == 0:
                raise IndLanRuntimeError("pop() on empty list", line)
            if len(args) > 1:
                return lst.pop(int(args[1]))
            return lst.pop()

        def ind_insert(args, line):
            if len(args) != 3:
                raise IndLanRuntimeError("insert() expects 3 arguments: list, index, value", line)
            lst, idx, val = args
            if not isinstance(lst, list):
                raise IndLanRuntimeError("insert() expects a list as first argument", line)
            lst.insert(int(idx), val)
            return lst

        def ind_remove(args, line):
            if len(args) != 2:
                raise IndLanRuntimeError("remove() expects 2 arguments: list, value", line)
            lst, val = args
            if not isinstance(lst, list):
                raise IndLanRuntimeError("remove() expects a list", line)
            try:
                lst.remove(val)
            except ValueError:
                raise IndLanRuntimeError(f"remove(): value {val!r} not in list", line)
            return lst

        def ind_reverse(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("reverse() expects 1 argument (list)", line)
            lst = args[0]
            if not isinstance(lst, list):
                raise IndLanRuntimeError("reverse() expects a list", line)
            lst.reverse()
            return lst

        def ind_sort(args, line):
            if not args or not isinstance(args[0], list):
                raise IndLanRuntimeError("sort() expects a list", line)
            lst = args[0]
            try:
                lst.sort()
            except TypeError:
                raise IndLanRuntimeError("sort(): list contains mixed non-comparable types", line)
            return lst

        def ind_keys(args, line):
            if len(args) != 1 or not isinstance(args[0], dict):
                raise IndLanRuntimeError("keys() expects a dict", line)
            return list(args[0].keys())

        def ind_values(args, line):
            if len(args) != 1 or not isinstance(args[0], dict):
                raise IndLanRuntimeError("values() expects a dict", line)
            return list(args[0].values())

        def ind_has(args, line):
            """has(collection, item) -> bool: works on lists, dicts (key), strings (substring)"""
            if len(args) != 2:
                raise IndLanRuntimeError("has() expects 2 arguments: collection, item", line)
            col, item = args
            if isinstance(col, (list, dict, str)):
                return item in col
            raise IndLanRuntimeError("has() expects a list, dict, or string", line)

        def ind_abs(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("abs() expects 1 argument", line)
            v = args[0]
            if not isinstance(v, (int, float)):
                raise IndLanRuntimeError("abs() expects a number", line)
            return abs(v)

        def ind_max(args, line):
            if not args:
                raise IndLanRuntimeError("max() expects at least 1 argument", line)
            items = args[0] if len(args) == 1 and isinstance(args[0], list) else args
            try:
                return max(items)
            except TypeError:
                raise IndLanRuntimeError("max(): cannot compare mixed types", line)

        def ind_min(args, line):
            if not args:
                raise IndLanRuntimeError("min() expects at least 1 argument", line)
            items = args[0] if len(args) == 1 and isinstance(args[0], list) else args
            try:
                return min(items)
            except TypeError:
                raise IndLanRuntimeError("min(): cannot compare mixed types", line)

        def ind_floor(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("floor() expects 1 argument", line)
            import math
            return int(math.floor(args[0]))

        def ind_ceil(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("ceil() expects 1 argument", line)
            import math
            return int(math.ceil(args[0]))

        def ind_round(args, line):
            if len(args) not in (1, 2):
                raise IndLanRuntimeError("round() expects 1 or 2 arguments", line)
            ndigits = int(args[1]) if len(args) == 2 else 0
            return round(args[0], ndigits)

        def ind_sqrt(args, line):
            if len(args) != 1:
                raise IndLanRuntimeError("sqrt() expects 1 argument", line)
            import math
            if args[0] < 0:
                raise IndLanRuntimeError("sqrt() of negative number", line)
            return math.sqrt(args[0])

        builtins = {
            # I/O
            "print": ind_print,
            "chhap": ind_print,
            "input": ind_input,
            "aalao": ind_input,           # Hindi: "aa lo" = bring/take
            "input_int": ind_input_int,
            "number_dalao": ind_input_int, # Hindi: "number daalo" = enter a number
            "input_float": ind_input_float,
            "decimal_dalao": ind_input_float, # Hindi: decimal number
            "input_bool": ind_input_bool,
            "haan_na": ind_input_bool,    # Hindi: "haan/na" = yes/no
            # type conversion
            "str": ind_str,
            "int": ind_int,
            "float": ind_float,
            "bool": ind_bool,
            "char": ind_char,
            "type": ind_type,
            # collections
            "len": ind_len,
            "range": ind_range,
            "append": ind_append,
            "pop": ind_pop,
            "insert": ind_insert,
            "remove": ind_remove,
            "reverse": ind_reverse,
            "sort": ind_sort,
            "keys": ind_keys,
            "values": ind_values,
            "has": ind_has,
            # math
            "abs": ind_abs,
            "max": ind_max,
            "min": ind_min,
            "floor": ind_floor,
            "ceil": ind_ceil,
            "round": ind_round,
            "sqrt": ind_sqrt,
        }
        for name, fn in builtins.items():
            self.globals.define(name, fn)

    # ---------- driver ----------

    def run(self, program):
        env = self.globals
        for stmt in program.statements:
            self.execute(stmt, env)

    # ---------- statement execution ----------

    def execute(self, node, env):
        method = getattr(self, f"exec_{type(node).__name__}", None)
        if method is None:
            raise IndLanRuntimeError(f"No executor for statement {type(node).__name__}")
        return method(node, env)

    def exec_block(self, block, env):
        for stmt in block.statements:
            self.execute(stmt, env)

    def exec_Block(self, node, env):
        inner = Environment(env)
        self.exec_block(node, inner)

    def exec_LetStmt(self, node, env):
        value = self.evaluate(node.value, env)
        env.define(node.name, value)

    def exec_ExprStmt(self, node, env):
        self.evaluate(node.expr, env)

    def exec_FunDecl(self, node, env):
        fn = IndFunction(node.name, node.params, node.body, env, self)
        env.define(node.name, fn)

    def exec_ClassDecl(self, node, env):
        methods = {}
        for m in node.methods:
            methods[m.name] = IndFunction(m.name, m.params, m.body, env, self)
        klass = IndClass(node.name, methods)
        env.define(node.name, klass)

    def exec_IfStmt(self, node, env):
        for cond, body in node.branches:
            if self.truthy(self.evaluate(cond, env)):
                inner = Environment(env)
                self.exec_block(body, inner)
                return
        if node.else_block is not None:
            inner = Environment(env)
            self.exec_block(node.else_block, inner)

    def exec_WhileStmt(self, node, env):
        while self.truthy(self.evaluate(node.condition, env)):
            inner = Environment(env)
            try:
                self.exec_block(node.body, inner)
            except BreakSignal:
                break
            except ContinueSignal:
                continue

    def exec_DoWhileStmt(self, node, env):
        while True:
            inner = Environment(env)
            try:
                self.exec_block(node.body, inner)
            except BreakSignal:
                break
            except ContinueSignal:
                pass
            if not self.truthy(self.evaluate(node.condition, env)):
                break

    def exec_SwitchStmt(self, node, env):
        subject_val = self.evaluate(node.subject, env)
        for value_expr, body in node.cases:
            case_val = self.evaluate(value_expr, env)
            if self.is_equal(subject_val, case_val):
                inner = Environment(env)
                try:
                    self.exec_block(body, inner)
                except BreakSignal:
                    pass
                return
        if node.default_block is not None:
            inner = Environment(env)
            try:
                self.exec_block(node.default_block, inner)
            except BreakSignal:
                pass

    def exec_ForStmt(self, node, env):
        iterable = self.evaluate(node.iterable, env)
        if isinstance(iterable, dict):
            items = list(iterable.keys())
        elif isinstance(iterable, (list, str)):
            items = list(iterable)
        else:
            raise IndLanRuntimeError(f"Cannot iterate over this value", node.line)
        for item in items:
            inner = Environment(env)
            inner.define(node.var_name, item)
            try:
                self.exec_block(node.body, inner)
            except BreakSignal:
                break
            except ContinueSignal:
                continue

    def exec_ReturnStmt(self, node, env):
        value = self.evaluate(node.value, env) if node.value is not None else None
        raise ReturnSignal(value)

    def exec_BreakStmt(self, node, env):
        raise BreakSignal()

    def exec_ContinueStmt(self, node, env):
        raise ContinueSignal()

    # ---------- expression evaluation ----------

    def evaluate(self, node, env):
        method = getattr(self, f"eval_{type(node).__name__}", None)
        if method is None:
            raise IndLanRuntimeError(f"No evaluator for expression {type(node).__name__}")
        return method(node, env)

    def eval_NumberLit(self, node, env):
        return node.value

    def eval_StringLit(self, node, env):
        return node.value

    def eval_FStringLit(self, node, env):
        """Evaluate each part: string literals pass through, expr parts are evaluated."""
        pieces = []
        for kind, content in node.parts:
            if kind == "str":
                pieces.append(content)
            else:
                # Parse and evaluate the embedded expression
                try:
                    toks = tokenize(content)
                    prog = parse(toks)
                    # prog is a Program with one ExprStmt
                    val = self.evaluate(prog.statements[0].expr, env)
                    pieces.append(self.stringify(val))
                except (LexError, ParseError) as e:
                    raise IndLanRuntimeError(f"f-string expression error: {e}", node.line)
        return "".join(pieces)

    def eval_BoolLit(self, node, env):
        return node.value

    def eval_NullLit(self, node, env):
        return None

    def eval_ListLit(self, node, env):
        return [self.evaluate(e, env) for e in node.elements]

    def eval_DictLit(self, node, env):
        result = {}
        for k, v in node.pairs:
            key = self.evaluate(k, env)
            result[key] = self.evaluate(v, env)
        return result

    def eval_Identifier(self, node, env):
        return env.get(node.name, node.line)

    def eval_UnaryOp(self, node, env):
        val = self.evaluate(node.operand, env)
        if node.op == "-":
            self.check_number(val, node.line)
            return -val
        if node.op == "not":
            return not self.truthy(val)
        raise IndLanRuntimeError(f"Unknown unary operator '{node.op}'", node.line)

    def eval_BinOp(self, node, env):
        left = self.evaluate(node.left, env)
        right = self.evaluate(node.right, env)
        op = node.op
        line = node.line

        if op == "+":
            if isinstance(left, str) or isinstance(right, str):
                return self.stringify(left) + self.stringify(right)
            if isinstance(left, list) and isinstance(right, list):
                return left + right
            self.check_number(left, line); self.check_number(right, line)
            return left + right
        if op == "-":
            self.check_number(left, line); self.check_number(right, line)
            return left - right
        if op == "*":
            # string * int repetition
            if isinstance(left, str) and isinstance(right, int):
                return left * right
            if isinstance(left, list) and isinstance(right, int):
                return left * right
            self.check_number(left, line); self.check_number(right, line)
            return left * right
        if op == "/":
            self.check_number(left, line); self.check_number(right, line)
            if right == 0:
                raise IndLanRuntimeError("Division by zero", line)
            result = left / right
            if isinstance(left, int) and isinstance(right, int) and left % right == 0:
                return int(result)
            return round(result, 10)
        if op == "%":
            self.check_number(left, line); self.check_number(right, line)
            if right == 0:
                raise IndLanRuntimeError("Modulo by zero", line)
            return left % right
        if op == "**":
            self.check_number(left, line); self.check_number(right, line)
            result = left ** right
            # keep int when possible
            if isinstance(result, complex):
                raise IndLanRuntimeError("Exponentiation produced a complex number", line)
            return result
        if op == "==":
            return self.is_equal(left, right)
        if op == "!=":
            return not self.is_equal(left, right)
        if op == "<":
            return left < right
        if op == ">":
            return left > right
        if op == "<=":
            return left <= right
        if op == ">=":
            return left >= right

        raise IndLanRuntimeError(f"Unknown binary operator '{op}'", line)

    def eval_LogicalOp(self, node, env):
        left = self.evaluate(node.left, env)
        if node.op == "and":
            if not self.truthy(left):
                return left
            return self.evaluate(node.right, env)
        else:  # or
            if self.truthy(left):
                return left
            return self.evaluate(node.right, env)

    def eval_Assign(self, node, env):
        value = self.evaluate(node.value, env)
        target = node.target

        if node.op != "=":
            current = self.evaluate(target, env)
            base_op = node.op[0]  # '+', '-', '*', '/'
            fake_bin = BinOp(base_op, Wrapped(current), Wrapped(value), node.line)
            value = self.eval_BinOp(fake_bin, env)

        if isinstance(target, Identifier):
            env.set(target.name, value, node.line)
        elif isinstance(target, Index):
            obj = self.evaluate(target.obj, env)
            idx = self.evaluate(target.index, env)
            if isinstance(obj, list):
                i = int(idx)
                if i < -len(obj) or i >= len(obj):
                    raise IndLanRuntimeError(f"List index {i} out of range", node.line)
                obj[i] = value
            elif isinstance(obj, dict):
                obj[idx] = value
            else:
                raise IndLanRuntimeError("Cannot index-assign to this type", node.line)
        elif isinstance(target, GetAttr):
            obj = self.evaluate(target.obj, env)
            if isinstance(obj, IndInstance):
                obj.set(target.name, value)
            else:
                raise IndLanRuntimeError("Cannot set attribute on this type", node.line)
        else:
            raise IndLanRuntimeError("Invalid assignment target", node.line)
        return value

    def eval_Call(self, node, env):
        line = node.line
        args = [self.evaluate(a, env) for a in node.args]

        # Class instantiation: new ClassName(...) parses as Call(Identifier(name), args)
        if isinstance(node.callee, Identifier) and env.has(node.callee.name):
            callee_val = env.get(node.callee.name, line)
            if isinstance(callee_val, IndClass):
                instance = IndInstance(callee_val)
                init = callee_val.find_method("init")
                if init is not None:
                    init.bind(instance).call(args, line)
                elif args:
                    raise IndLanRuntimeError(
                        f"Class '{callee_val.name}' has no init() but was called with arguments", line)
                return instance

        callee = self.evaluate(node.callee, env)

        if callable(callee) and not isinstance(callee, IndFunction):
            return callee(args, line)
        if isinstance(callee, IndFunction):
            return callee.call(args, line)

        raise IndLanRuntimeError(f"'{self.stringify(callee)}' is not callable", line)

    def eval_Index(self, node, env):
        obj = self.evaluate(node.obj, env)
        idx = self.evaluate(node.index, env)
        if isinstance(obj, list):
            i = int(idx)
            if i < -len(obj) or i >= len(obj):
                raise IndLanRuntimeError(f"List index {i} out of range", node.line)
            return obj[i]
        if isinstance(obj, dict):
            if idx not in obj:
                raise IndLanRuntimeError(f"Key {idx!r} not found in dict", node.line)
            return obj[idx]
        if isinstance(obj, str):
            i = int(idx)
            if i < -len(obj) or i >= len(obj):
                raise IndLanRuntimeError(f"String index {i} out of range", node.line)
            return obj[i]
        raise IndLanRuntimeError("Cannot index this type", node.line)

    def eval_GetAttr(self, node, env):
        obj = self.evaluate(node.obj, env)
        if isinstance(obj, IndInstance):
            return obj.get(node.name, node.line)
        if isinstance(obj, str):
            return self.make_string_method(obj, node.name, node.line)
        if isinstance(obj, list):
            return self.make_list_method(obj, node.name, node.line)
        raise IndLanRuntimeError(f"Cannot get attribute '{node.name}' on this type", node.line)

    def make_string_method(self, s, name, line):
        if name == "upper":    return lambda args, l: s.upper()
        if name == "lower":    return lambda args, l: s.lower()
        if name == "strip":    return lambda args, l: s.strip()
        if name == "lstrip":   return lambda args, l: s.lstrip()
        if name == "rstrip":   return lambda args, l: s.rstrip()
        if name == "split":    return lambda args, l: s.split(*args) if args else s.split()
        if name == "replace":
            def _replace(args, l):
                if len(args) != 2:
                    raise IndLanRuntimeError("replace() expects 2 arguments: old, new", l)
                return s.replace(args[0], args[1])
            return _replace
        if name == "startswith": return lambda args, l: s.startswith(args[0]) if args else False
        if name == "endswith":   return lambda args, l: s.endswith(args[0]) if args else False
        if name == "contains":   return lambda args, l: args[0] in s if args else False
        if name == "find":       return lambda args, l: s.find(args[0]) if args else -1
        if name == "len":        return lambda args, l: len(s)
        raise IndLanRuntimeError(f"String has no method '{name}'", line)

    def make_list_method(self, lst, name, line):
        if name == "len":     return lambda args, l: len(lst)
        if name == "append":  return lambda args, l: lst.append(args[0]) or lst
        if name == "pop":     return lambda args, l: lst.pop(int(args[0])) if args else lst.pop()
        if name == "reverse": return lambda args, l: lst.reverse() or lst
        if name == "sort":    return lambda args, l: lst.sort() or lst
        if name == "contains":return lambda args, l: args[0] in lst if args else False
        raise IndLanRuntimeError(f"List has no method '{name}'", line)

    # ---------- helpers ----------

    def check_number(self, val, line):
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            raise IndLanRuntimeError(f"Expected a number, got {self.stringify(val)!r}", line)

    def truthy(self, val):
        if val is None or val is False:
            return False
        if val == 0:
            return False
        if val == "":
            return False
        if isinstance(val, (list, dict)) and len(val) == 0:
            return False
        return True

    def is_equal(self, a, b):
        if type(a) != type(b) and not (isinstance(a, (int, float)) and isinstance(b, (int, float))):
            return False
        return a == b

    def stringify(self, val):
        if val is None:
            return "null"
        if val is True:
            return "true"
        if val is False:
            return "false"
        if isinstance(val, float):
            if val == int(val) and not (val != val):  # not NaN
                return f"{val:.1f}"
            return str(val)
        if isinstance(val, list):
            return "[" + ", ".join(self.stringify(v) for v in val) + "]"
        if isinstance(val, dict):
            items = ", ".join(f"{self.stringify(k)}: {self.stringify(v)}" for k, v in val.items())
            return "{" + items + "}"
        return str(val)


class Wrapped(Node):
    """Helper node used internally to feed already-evaluated values back into eval_BinOp."""
    def __init__(self, value):
        self.value = value
        self.line = 0


def _eval_wrapped(self, node, env):
    return node.value

Interpreter.eval_Wrapped = _eval_wrapped
